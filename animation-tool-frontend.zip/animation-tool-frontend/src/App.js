import React from "react";
import FileUpload from "./components/FileUpload";

const App = () => {
  return (
    <div>
      <FileUpload />
    </div>
  );
};

export default App;
