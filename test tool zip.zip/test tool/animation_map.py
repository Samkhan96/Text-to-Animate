# animation_map.py

animation_map = {
    "walk": "animations/walk.fbx",
    "run": "animations/run.fbx",
    "jump": "animations/jump.fbx",
    # Add more commands and paths as needed
}
