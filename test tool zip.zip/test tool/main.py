from fastapi import FastAPI
from fastapi.responses import FileResponse
import os
from fastapi.responses import JSONResponse
from fastapi.exceptions import HTTPException
from pathlib import Path

app = FastAPI()

# Animation file dictionary (example)
ANIMATION_FILES = {
    "walk": "animations/walk.fbx",
    "run": "animations/run.fbx",
    # Add more commands as needed
}

@app.post("/animate")
async def animate(data: dict):
    try:
        # Step 1: Check if 'command' is present in the request body
        command = data.get("command")
        if not command:
            return JSONResponse(
                status_code=422,
                content={"error": "Missing 'command' in request body."},
            )
        
        # Step 2: Validate if the command exists in ANIMATION_FILES
        if command not in ANIMATION_FILES:
            return JSONResponse(
                status_code=400,
                content={"error": f"Invalid command: '{command}'. Available commands are: {list(ANIMATION_FILES.keys())}"},
            )
        
        # Step 3: Check if the file path exists
        animation_path = Path(ANIMATION_FILES[command])
        if not animation_path.exists():
            return JSONResponse(
                status_code=500,
                content={"error": f"Animation file not found for command: '{command}'. Path: '{animation_path}'"},
            )
        
        # Step 4: Serve the animation file
        return FileResponse(path=animation_path, filename=f"{command}.fbx")
    
    except Exception as e:
        # Catch-all error handler for unexpected issues
        return JSONResponse(
            status_code=500,
            content={"error": f"An unexpected error occurred: {str(e)}"},
        )
