import os

def get_action_from_text(prompt):
    """
    Mocked function to simulate extracting an action from user input.
    Replace this with actual OpenAI API logic when the API is available.
    """
    # Mocked responses for testing purposes
    mock_actions = {
        "walk": "walk",
        "run": "run",
        "jump": "jump",
        "dance": "dance",
        "fight": "fight",
        "sit": "sit",
        "fly": "fly",
        "walking": "walking",
    }
    
    # Check if the input matches any predefined actions
    for action in mock_actions:
        if action in prompt.lower():
            return mock_actions[action]  # Return the matched action
    
    return "unknown"  # Default if no match is found


def find_animation_file(action, animations_folder):
    """
    Searches for the animation file corresponding to the action in the animations folder.
    """
    animation_file = os.path.join(animations_folder, f"{action}.fbx")
    if os.path.exists(animation_file):
        return animation_file
    else:
        return None


def main():
    print("Welcome to the Text-to-Animation Tool!")
    animations_folder = "animations"  # Ensure this folder exists and contains .fbx files

    while True:
        user_input = input("\nEnter an animation command (or 'exit' to quit): ")
        
        if user_input.lower() == "exit":
            print("Exiting the tool. Goodbye!")
            break

        # Use the mocked function to simulate action extraction
        action = get_action_from_text(user_input)
        if action == "unknown":
            print("Could not understand the command. Please try again.")
            continue

        # Search for the corresponding animation file
        animation_file = find_animation_file(action, animations_folder)
        if animation_file:
            print(f"Matched Animation: {animation_file}")
        else:
            print("No matching animation found. Try another command.")


if __name__ == "__main__":
    main()
